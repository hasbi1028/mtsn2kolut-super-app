
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/api" | "/api/attendance" | "/api/auth" | "/api/auth/change-password" | "/api/auth/logout" | "/api/employees" | "/api/jobs" | "/api/jobs/cancel-all" | "/api/jobs/cancel" | "/api/jobs/run-all" | "/api/jobs/run-now" | "/api/queue" | "/api/queue/stats" | "/api/scheduler" | "/api/scheduler/tick" | "/api/schedules" | "/api/settings" | "/api/worker" | "/api/worker/claim" | "/api/worker/complete" | "/api/worker/fail" | "/api/worker/restart" | "/attendance" | "/employees" | "/jobs" | "/login" | "/settings";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/api": Record<string, never>;
			"/api/attendance": Record<string, never>;
			"/api/auth": Record<string, never>;
			"/api/auth/change-password": Record<string, never>;
			"/api/auth/logout": Record<string, never>;
			"/api/employees": Record<string, never>;
			"/api/jobs": Record<string, never>;
			"/api/jobs/cancel-all": Record<string, never>;
			"/api/jobs/cancel": Record<string, never>;
			"/api/jobs/run-all": Record<string, never>;
			"/api/jobs/run-now": Record<string, never>;
			"/api/queue": Record<string, never>;
			"/api/queue/stats": Record<string, never>;
			"/api/scheduler": Record<string, never>;
			"/api/scheduler/tick": Record<string, never>;
			"/api/schedules": Record<string, never>;
			"/api/settings": Record<string, never>;
			"/api/worker": Record<string, never>;
			"/api/worker/claim": Record<string, never>;
			"/api/worker/complete": Record<string, never>;
			"/api/worker/fail": Record<string, never>;
			"/api/worker/restart": Record<string, never>;
			"/attendance": Record<string, never>;
			"/employees": Record<string, never>;
			"/jobs": Record<string, never>;
			"/login": Record<string, never>;
			"/settings": Record<string, never>
		};
		Pathname(): "/" | "/api/attendance" | "/api/auth/change-password" | "/api/auth/logout" | "/api/employees" | "/api/jobs" | "/api/jobs/cancel-all" | "/api/jobs/cancel" | "/api/jobs/run-all" | "/api/jobs/run-now" | "/api/queue/stats" | "/api/scheduler/tick" | "/api/schedules" | "/api/settings" | "/api/worker/claim" | "/api/worker/complete" | "/api/worker/fail" | "/api/worker/restart" | "/attendance" | "/employees" | "/jobs" | "/login" | "/settings";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}