

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/attendance/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.DcO1YXo7.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/v_jBEYI6.js"];
export const stylesheets = ["_app/immutable/assets/4.BbbTOOpc.css"];
export const fonts = [];
