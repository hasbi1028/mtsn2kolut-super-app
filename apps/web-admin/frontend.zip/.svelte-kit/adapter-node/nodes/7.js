

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.B2uPLICD.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/v_jBEYI6.js"];
export const stylesheets = ["_app/immutable/assets/7.CVLL4q2o.css"];
export const fonts = [];
