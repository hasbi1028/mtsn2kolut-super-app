

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BFRj2mid.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/zjuSOkt2.js","_app/immutable/chunks/KAguBumh.js","_app/immutable/chunks/v_jBEYI6.js"];
export const stylesheets = [];
export const fonts = [];
