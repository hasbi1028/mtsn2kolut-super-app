

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/attendance/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.gUDC6SgY.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/v_jBEYI6.js"];
export const stylesheets = ["_app/immutable/assets/2.CiwYt7vD.css"];
export const fonts = [];
