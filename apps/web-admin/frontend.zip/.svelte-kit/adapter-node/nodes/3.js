

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.DAZM6-iD.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/v_jBEYI6.js"];
export const stylesheets = ["_app/immutable/assets/3.CSMOU4d0.css"];
export const fonts = [];
