import fs from "fs";
import path from "path";
//#region src/lib/server/logger.ts
var LOG_PATH = process.env.APP_LOG_PATH ?? path.resolve("../logs/app.log");
fs.mkdirSync(path.dirname(LOG_PATH), { recursive: true });
function logInfo(message, context = {}) {
	writeLog("INFO", message, context);
}
function logWarn(message, context = {}) {
	writeLog("WARN", message, context);
}
function logError(message, context = {}) {
	writeLog("ERROR", message, context);
}
function writeLog(level, message, context) {
	const line = `${(/* @__PURE__ */ new Date()).toISOString()} [${level}] ${message} ${JSON.stringify(context)}\n`;
	try {
		fs.appendFileSync(LOG_PATH, line);
	} catch {}
	if (level === "ERROR") console.error(line.trim());
	else if (level === "WARN") console.warn(line.trim());
	else console.log(line.trim());
}
//#endregion
export { logInfo as n, logWarn as r, logError as t };
