import { t as __exportAll } from "./chunk.js";
import BetterSqlite3 from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import fs from "fs";
import path from "path";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
//#region src/lib/server/schema.ts
var schema_exports = /* @__PURE__ */ __exportAll({
	appSettings: () => appSettings,
	attendanceRecords: () => attendanceRecords,
	employees: () => employees,
	jobs: () => jobs,
	schedules: () => schedules
});
var now = sql`CURRENT_TIMESTAMP`;
var employees = sqliteTable("employees", {
	id: text("id").primaryKey(),
	nip: text("nip").notNull().unique(),
	nama: text("nama").notNull(),
	unit_kerja: text("unit_kerja").notNull().default(""),
	pusaka_username: text("pusaka_username").notNull(),
	pusaka_password: text("pusaka_password").notNull(),
	is_active: integer("is_active").notNull().default(1),
	created_at: text("created_at").notNull().default(now),
	updated_at: text("updated_at").notNull().default(now)
});
var schedules = sqliteTable("schedules", {
	id: text("id").primaryKey(),
	label: text("label").notNull(),
	run_time: text("run_time").notNull(),
	run_type: text("run_type", { enum: [
		"morning",
		"afternoon",
		"checkin",
		"checkout"
	] }).notNull(),
	is_enabled: integer("is_enabled").notNull().default(1),
	created_at: text("created_at").notNull().default(now),
	updated_at: text("updated_at").notNull().default(now)
});
var jobs = sqliteTable("jobs", {
	id: text("id").primaryKey(),
	employee_id: text("employee_id").notNull().references(() => employees.id),
	run_type: text("run_type", { enum: [
		"morning",
		"afternoon",
		"checkin",
		"checkout"
	] }).notNull(),
	status: text("status", { enum: [
		"queued",
		"running",
		"success",
		"failed"
	] }).notNull(),
	error_message: text("error_message").notNull().default(""),
	claimed_by: text("claimed_by").notNull().default(""),
	claimed_at: text("claimed_at"),
	attempts: integer("attempts").notNull().default(0),
	max_attempts: integer("max_attempts").notNull().default(3),
	next_retry_at: text("next_retry_at"),
	created_at: text("created_at").notNull().default(now),
	updated_at: text("updated_at").notNull().default(now)
}, (t) => [
	index("idx_jobs_status_created_at").on(t.status, t.created_at),
	index("idx_jobs_employee_run_status").on(t.employee_id, t.run_type, t.status),
	index("idx_jobs_next_retry_at").on(t.next_retry_at)
]);
var attendanceRecords = sqliteTable("attendance_records", {
	id: text("id").primaryKey(),
	employee_id: text("employee_id").notNull().references(() => employees.id),
	tanggal: text("tanggal").notNull(),
	jam_masuk: text("jam_masuk").notNull().default(""),
	jam_pulang: text("jam_pulang").notNull().default(""),
	source_job_id: text("source_job_id").notNull().references(() => jobs.id),
	created_at: text("created_at").notNull().default(now),
	updated_at: text("updated_at").notNull().default(now)
}, (t) => [uniqueIndex("uq_attendance_employee_tanggal").on(t.employee_id, t.tanggal)]);
var appSettings = sqliteTable("app_settings", {
	key: text("key").primaryKey(),
	value: text("value").notNull().default(""),
	updated_at: text("updated_at").notNull().default(now)
});
//#endregion
//#region src/lib/server/db.ts
var DB_PATH = process.env.DB_PATH ?? path.resolve("../data/pusaka.sqlite");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
var sqlite = new BetterSqlite3(DB_PATH);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");
sqlite.exec(`
CREATE TABLE IF NOT EXISTS employees (
  id               TEXT PRIMARY KEY,
  nip              TEXT NOT NULL UNIQUE,
  nama             TEXT NOT NULL,
  unit_kerja       TEXT NOT NULL DEFAULT '',
  pusaka_username  TEXT NOT NULL,
  pusaka_password  TEXT NOT NULL,
  is_active        INTEGER NOT NULL DEFAULT 1,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS schedules (
  id          TEXT PRIMARY KEY,
  label       TEXT NOT NULL,
  run_time    TEXT NOT NULL,
  run_type    TEXT NOT NULL CHECK(run_type IN ('morning','afternoon','checkin','checkout')),
  is_enabled  INTEGER NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS jobs (
  id            TEXT PRIMARY KEY,
  employee_id   TEXT NOT NULL,
  run_type      TEXT NOT NULL CHECK(run_type IN ('morning','afternoon','checkin','checkout')),
  status        TEXT NOT NULL CHECK(status IN ('queued','running','success','failed')),
  error_message TEXT NOT NULL DEFAULT '',
  claimed_by    TEXT NOT NULL DEFAULT '',
  claimed_at    DATETIME,
  attempts      INTEGER NOT NULL DEFAULT 0,
  max_attempts  INTEGER NOT NULL DEFAULT 3,
  next_retry_at DATETIME,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(employee_id) REFERENCES employees(id)
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id            TEXT PRIMARY KEY,
  employee_id   TEXT NOT NULL,
  tanggal       TEXT NOT NULL,
  jam_masuk     TEXT NOT NULL DEFAULT '',
  jam_pulang    TEXT NOT NULL DEFAULT '',
  source_job_id TEXT NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(employee_id, tanggal),
  FOREIGN KEY(employee_id)   REFERENCES employees(id),
  FOREIGN KEY(source_job_id) REFERENCES jobs(id)
);

CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_jobs_status_created_at    ON jobs(status, created_at);
CREATE INDEX IF NOT EXISTS idx_jobs_employee_run_status  ON jobs(employee_id, run_type, status);
CREATE INDEX IF NOT EXISTS idx_jobs_next_retry_at        ON jobs(next_retry_at);
`);
migrateSchema();
seedDefaults();
var db = drizzle(sqlite, { schema: schema_exports });
var rawDb = sqlite;
function migrateSchema() {
	const cols = sqlite.prepare("PRAGMA table_info(jobs)").all().map((c) => c.name);
	if (!cols.includes("claimed_by")) sqlite.exec(`ALTER TABLE jobs ADD COLUMN claimed_by TEXT NOT NULL DEFAULT ''`);
	if (!cols.includes("claimed_at")) sqlite.exec(`ALTER TABLE jobs ADD COLUMN claimed_at DATETIME`);
	if (!cols.includes("attempts")) sqlite.exec(`ALTER TABLE jobs ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0`);
	if (!cols.includes("max_attempts")) sqlite.exec(`ALTER TABLE jobs ADD COLUMN max_attempts INTEGER NOT NULL DEFAULT 3`);
	if (!cols.includes("next_retry_at")) sqlite.exec(`ALTER TABLE jobs ADD COLUMN next_retry_at DATETIME`);
	migrateRunTypeConstraint();
}
function migrateRunTypeConstraint() {
	const newValues = [
		"morning",
		"afternoon",
		"checkin",
		"checkout"
	];
	for (const table of ["schedules", "jobs"]) {
		const row = sqlite.prepare(`SELECT sql FROM sqlite_master WHERE type='table' AND name=?`).get(table);
		if (!row) continue;
		const m = row.sql.match(/CHECK\s*\(\s*run_type\s+IN\s*\(([^)]+)\)\s*\)/i);
		const existing = m ? m[1].split(",").map((s) => s.trim().replace(/'/g, "")) : [];
		if (newValues.every((v) => existing.includes(v))) continue;
		const colDefs = sqlite.prepare(`PRAGMA table_info(${table})`).all().map((c) => {
			let def = `"${c.name}" ${c.type}`;
			if (c.notnull) def += " NOT NULL";
			if (c.dflt_value !== null) {
				const dv = c.dflt_value.startsWith("'") ? c.dflt_value : `'${c.dflt_value}'`;
				def += ` DEFAULT ${dv}`;
			}
			if (c.pk) def += " PRIMARY KEY";
			return def;
		});
		const fk = table === "jobs" ? `, FOREIGN KEY(employee_id) REFERENCES employees(id)` : "";
		const need = newValues.map((v) => `'${v}'`).join(",");
		const indexes = sqlite.prepare(`SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL`).all(table);
		sqlite.pragma("foreign_keys = OFF");
		try {
			sqlite.exec(`
				ALTER TABLE ${table} RENAME TO ${table}_old;
				CREATE TABLE ${table} (${colDefs.join(", ")}${fk}, CHECK(run_type IN (${need})));
				INSERT INTO ${table} SELECT * FROM ${table}_old;
				DROP TABLE ${table}_old;
			`);
		} finally {
			sqlite.pragma("foreign_keys = ON");
		}
		for (const idx of indexes) try {
			sqlite.exec(idx.sql);
		} catch {}
	}
}
function seedDefaults() {
	const existingTypes = sqlite.prepare("SELECT DISTINCT run_type FROM schedules").all().map((r) => r.run_type);
	const defaults = [
		{
			id: "sched-morning",
			label: "Pagi",
			run_time: "07:00",
			run_type: "morning"
		},
		{
			id: "sched-afternoon",
			label: "Sore",
			run_time: "16:00",
			run_type: "afternoon"
		},
		{
			id: "sched-checkin",
			label: "Absen Masuk",
			run_time: "06:30",
			run_type: "checkin"
		},
		{
			id: "sched-checkout",
			label: "Absen Pulang",
			run_time: "15:01",
			run_type: "checkout"
		}
	];
	const stmt = sqlite.prepare("INSERT OR IGNORE INTO schedules (id, label, run_time, run_type, is_enabled) VALUES (?, ?, ?, ?, 1)");
	for (const s of defaults) if (!existingTypes.includes(s.run_type)) stmt.run(s.id, s.label, s.run_time, s.run_type);
	const settingsDefaults = [["max_concurrent", "1"], ["headless", "0"]];
	const settingStmt = sqlite.prepare("INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)");
	for (const [key, value] of settingsDefaults) settingStmt.run(key, value);
}
//#endregion
export { jobs as a, employees as i, rawDb as n, schedules as o, appSettings as r, db as t };
