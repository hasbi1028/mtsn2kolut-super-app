import { o as schedules, t as db } from "./db.js";
import { t as enqueueAllActive } from "./queue.js";
import { n as logInfo, t as logError } from "./logger.js";
import { eq } from "drizzle-orm";
//#region src/lib/server/scheduler.ts
var TZ = "Asia/Makassar";
function nowMakassar() {
	const d = /* @__PURE__ */ new Date();
	return {
		date: new Intl.DateTimeFormat("en-CA", {
			timeZone: TZ,
			year: "numeric",
			month: "2-digit",
			day: "2-digit"
		}).format(d),
		time: new Intl.DateTimeFormat("en-GB", {
			timeZone: TZ,
			hour: "2-digit",
			minute: "2-digit",
			hour12: false
		}).format(d)
	};
}
function schedulerTick() {
	const { date, time } = nowMakassar();
	const rows = db.select().from(schedules).where(eq(schedules.is_enabled, 1)).all();
	globalThis.__scheduleRunCache ??= /* @__PURE__ */ new Set();
	let totalEnqueued = 0;
	for (const s of rows) {
		if (s.run_time !== time) continue;
		const key = `${date}:${s.id}:${s.run_time}`;
		if (globalThis.__scheduleRunCache.has(key)) continue;
		const result = enqueueAllActive(s.run_type, 3);
		totalEnqueued += result.inserted;
		globalThis.__scheduleRunCache.add(key);
		logInfo("scheduler enqueued jobs", {
			schedule_id: s.id,
			run_type: s.run_type,
			...result,
			at: `${date} ${time}`
		});
	}
	return totalEnqueued;
}
function initScheduler() {
	if (globalThis.__schedulerInitialized) return;
	globalThis.__schedulerInitialized = true;
	setInterval(() => {
		try {
			schedulerTick();
		} catch (e) {
			logError("scheduler tick failed", { error: e?.message ?? String(e) });
		}
	}, 3e4);
	logInfo("scheduler initialized", {});
}
//#endregion
export { schedulerTick as n, initScheduler as t };
