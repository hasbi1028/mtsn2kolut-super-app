import { n as rawDb } from "../../../../../chunks/db.js";
import { t as checkWorkerAuth } from "../../../../../chunks/workerAuth.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/worker/fail/+server.ts
var RETRY_BASE_SECONDS = 30;
var POST = async ({ request }) => {
	if (!checkWorkerAuth(request)) return json({ error: "Unauthorized" }, { status: 401 });
	const { job_id, error } = await request.json();
	if (!job_id) return json({ error: "job_id wajib" }, { status: 400 });
	const job = rawDb.prepare("SELECT attempts, max_attempts FROM jobs WHERE id = ?").get(job_id);
	if (!job) return json({ error: "Job tidak ditemukan" }, { status: 404 });
	const nextAttempts = Number(job.attempts) + 1;
	if (nextAttempts < Number(job.max_attempts)) {
		const delaySeconds = RETRY_BASE_SECONDS * Math.pow(2, nextAttempts - 1);
		rawDb.prepare(`
			UPDATE jobs
			SET status='queued', attempts=?, error_message=?,
			    next_retry_at=datetime(CURRENT_TIMESTAMP, '+' || ? || ' seconds'),
			    updated_at=CURRENT_TIMESTAMP
			WHERE id = ?
		`).run(nextAttempts, error, delaySeconds, job_id);
		return json({
			ok: true,
			action: "retry",
			attempts: nextAttempts,
			retry_in_seconds: delaySeconds
		});
	}
	rawDb.prepare(`
		UPDATE jobs
		SET status='failed', attempts=?, error_message=?, next_retry_at=NULL, updated_at=CURRENT_TIMESTAMP
		WHERE id = ?
	`).run(nextAttempts, error, job_id);
	return json({
		ok: true,
		action: "failed",
		attempts: nextAttempts
	});
};
//#endregion
export { POST };
