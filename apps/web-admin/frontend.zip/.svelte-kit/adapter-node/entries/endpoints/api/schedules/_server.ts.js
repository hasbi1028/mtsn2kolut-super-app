import { o as schedules, t as db } from "../../../../chunks/db.js";
import { json } from "@sveltejs/kit";
import { asc, eq } from "drizzle-orm";
//#region src/routes/api/schedules/+server.ts
var GET = () => {
	return json({ items: db.select().from(schedules).orderBy(asc(schedules.run_time)).all() });
};
var PUT = async ({ request }) => {
	const { schedules: rows } = await request.json();
	if (!Array.isArray(rows)) return json({ error: "schedules harus array" }, { status: 400 });
	db.transaction((tx) => {
		for (const s of rows) tx.update(schedules).set({
			label: s.label,
			run_time: s.run_time,
			run_type: s.run_type,
			is_enabled: s.is_enabled,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).where(eq(schedules.id, s.id)).run();
	});
	return json({ ok: true });
};
//#endregion
export { GET, PUT };
