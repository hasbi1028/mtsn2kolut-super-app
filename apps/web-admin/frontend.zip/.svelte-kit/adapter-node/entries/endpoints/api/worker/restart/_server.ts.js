import { json } from "@sveltejs/kit";
import { exec } from "child_process";
import { promisify } from "util";
//#region src/routes/api/worker/restart/+server.ts
var execAsync = promisify(exec);
var RESTART_CMD = process.env.WORKER_RESTART_CMD ?? "pm2 restart pusaka-worker";
var POST = async () => {
	try {
		await execAsync(RESTART_CMD);
		return json({ ok: true });
	} catch (err) {
		return json({ error: err instanceof Error ? err.message : "Gagal restart worker" }, { status: 500 });
	}
};
//#endregion
export { POST };
