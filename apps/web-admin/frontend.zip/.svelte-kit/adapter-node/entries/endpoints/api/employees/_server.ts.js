import { i as employees, n as rawDb, t as db } from "../../../../chunks/db.js";
import { json } from "@sveltejs/kit";
import { eq } from "drizzle-orm";
import crypto from "crypto";
//#region src/routes/api/employees/+server.ts
var DELETE = async ({ request }) => {
	const { id } = await request.json();
	if (!id) return json({ error: "id wajib diisi" }, { status: 400 });
	if (!db.select({ id: employees.id }).from(employees).where(eq(employees.id, id)).get()) return json({ error: "Pegawai tidak ditemukan" }, { status: 404 });
	rawDb.transaction(() => {
		rawDb.prepare("DELETE FROM attendance_records WHERE employee_id = ?").run(id);
		rawDb.prepare("DELETE FROM jobs WHERE employee_id = ?").run(id);
		rawDb.prepare("DELETE FROM employees WHERE id = ?").run(id);
	})();
	return json({ ok: true });
};
var GET = () => {
	return json({ items: rawDb.prepare(`
		SELECT
			e.id, e.nip, e.nama, e.unit_kerja, e.is_active, e.created_at,
			(SELECT j.status   FROM jobs j WHERE j.employee_id = e.id AND j.status IN ('running','queued')
			 ORDER BY CASE j.status WHEN 'running' THEN 0 ELSE 1 END, j.created_at DESC LIMIT 1) AS active_status,
			(SELECT j.run_type FROM jobs j WHERE j.employee_id = e.id AND j.status IN ('running','queued')
			 ORDER BY CASE j.status WHEN 'running' THEN 0 ELSE 1 END, j.created_at DESC LIMIT 1) AS active_run_type,
			(SELECT j.status   FROM jobs j WHERE j.employee_id = e.id ORDER BY j.created_at DESC LIMIT 1) AS last_status,
			(SELECT j.run_type FROM jobs j WHERE j.employee_id = e.id ORDER BY j.created_at DESC LIMIT 1) AS last_run_type
		FROM employees e
		ORDER BY e.created_at DESC
	`).all() });
};
var POST = async ({ request }) => {
	const { nip, nama, unit_kerja = "", pusaka_username, pusaka_password } = await request.json();
	if (!nip || !nama || !pusaka_username || !pusaka_password) return json({ error: "nip, nama, pusaka_username, pusaka_password wajib diisi" }, { status: 400 });
	try {
		db.insert(employees).values({
			id: crypto.randomUUID(),
			nip,
			nama,
			unit_kerja,
			pusaka_username,
			pusaka_password,
			is_active: 1
		}).run();
		return json({ ok: true }, { status: 201 });
	} catch {
		return json({ error: "Gagal menambah pegawai (mungkin NIP duplikat)" }, { status: 409 });
	}
};
//#endregion
export { DELETE, GET, POST };
