import { n as schedulerTick } from "../../../../../chunks/scheduler.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/scheduler/tick/+server.ts
var POST = () => json({ enqueued: schedulerTick() });
//#endregion
export { POST };
