import { t as enqueueAllActive } from "../../../../../chunks/queue.js";
import { n as logInfo } from "../../../../../chunks/logger.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/jobs/run-all/+server.ts
var POST = async ({ request }) => {
	const payload = await request.json().catch(() => ({}));
	const run_type = payload?.run_type === "afternoon" ? "afternoon" : payload?.run_type === "checkin" ? "checkin" : payload?.run_type === "checkout" ? "checkout" : "morning";
	const result = enqueueAllActive(run_type, Math.max(1, Math.min(Number(payload?.max_attempts ?? 3), 10)));
	logInfo("run-all enqueued", {
		run_type,
		...result
	});
	return json({
		run_type,
		...result
	}, { status: 201 });
};
//#endregion
export { POST };
