import { n as rawDb } from "../../../../../chunks/db.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/jobs/cancel/+server.ts
var POST = async ({ request }) => {
	const { employee_id } = await request.json();
	if (!employee_id) return json({ error: "employee_id wajib" }, { status: 400 });
	return json({
		ok: true,
		cancelled: rawDb.prepare(`UPDATE jobs SET status='failed', error_message='Dibatalkan manual', next_retry_at=NULL, updated_at=CURRENT_TIMESTAMP
		 WHERE employee_id=? AND status IN ('queued','running')`).run(employee_id).changes
	});
};
//#endregion
export { POST };
