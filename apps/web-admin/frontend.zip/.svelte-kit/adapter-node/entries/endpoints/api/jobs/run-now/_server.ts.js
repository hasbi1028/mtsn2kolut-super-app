import { i as employees, t as db } from "../../../../../chunks/db.js";
import { n as enqueueOne } from "../../../../../chunks/queue.js";
import { n as logInfo, r as logWarn } from "../../../../../chunks/logger.js";
import { json } from "@sveltejs/kit";
import { and, eq } from "drizzle-orm";
//#region src/routes/api/jobs/run-now/+server.ts
var POST = async ({ request }) => {
	const { employee_id, run_type = "morning" } = await request.json();
	if (!employee_id) return json({ error: "employee_id wajib" }, { status: 400 });
	const emp = db.select({
		id: employees.id,
		nip: employees.nip,
		nama: employees.nama
	}).from(employees).where(and(eq(employees.id, employee_id), eq(employees.is_active, 1))).get();
	if (!emp) return json({ error: "Pegawai tidak ditemukan / nonaktif" }, { status: 404 });
	if (enqueueOne(employee_id, run_type, 3).inserted === 0) {
		logWarn("run-now skipped duplicate job", {
			employee_id,
			run_type
		});
		return json({
			inserted: 0,
			skipped: 1,
			reason: "job queued/running already exists"
		});
	}
	logInfo("run-now enqueued", {
		employee_id,
		nip: emp.nip,
		nama: emp.nama,
		run_type
	});
	return json({
		inserted: 1,
		skipped: 0
	}, { status: 201 });
};
//#endregion
export { POST };
