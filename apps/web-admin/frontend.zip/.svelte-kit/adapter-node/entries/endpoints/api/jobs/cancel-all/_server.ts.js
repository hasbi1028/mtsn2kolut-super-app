import { n as rawDb } from "../../../../../chunks/db.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/jobs/cancel-all/+server.ts
var POST = () => {
	return json({
		ok: true,
		cancelled: rawDb.prepare(`UPDATE jobs SET status='failed', error_message='Dibatalkan manual', next_retry_at=NULL, updated_at=CURRENT_TIMESTAMP
		 WHERE status IN ('queued','running')`).run().changes
	});
};
//#endregion
export { POST };
