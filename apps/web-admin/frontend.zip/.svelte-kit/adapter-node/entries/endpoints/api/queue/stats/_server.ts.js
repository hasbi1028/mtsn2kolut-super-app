import { r as getQueueStats } from "../../../../../chunks/queue.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/queue/stats/+server.ts
var GET = () => json(getQueueStats());
//#endregion
export { GET };
