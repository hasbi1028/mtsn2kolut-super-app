import { r as appSettings, t as db } from "../../../../chunks/db.js";
import { n as logInfo } from "../../../../chunks/logger.js";
import { json } from "@sveltejs/kit";
import "drizzle-orm";
//#region src/lib/server/settings.ts
function getAppSettings() {
	const rows = db.select().from(appSettings).all();
	const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
	return {
		max_concurrent: Math.max(1, Number(map.max_concurrent ?? 1)),
		headless: map.headless === "1" || map.headless === "true"
	};
}
function updateAppSettings(input) {
	const next = getAppSettings();
	if (input.max_concurrent !== void 0) next.max_concurrent = Math.max(1, Math.min(20, Number(input.max_concurrent) || 1));
	if (input.headless !== void 0) next.headless = Boolean(input.headless);
	db.transaction((tx) => {
		tx.insert(appSettings).values({
			key: "max_concurrent",
			value: String(next.max_concurrent)
		}).onConflictDoUpdate({
			target: appSettings.key,
			set: {
				value: String(next.max_concurrent),
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}
		}).run();
		tx.insert(appSettings).values({
			key: "headless",
			value: next.headless ? "1" : "0"
		}).onConflictDoUpdate({
			target: appSettings.key,
			set: {
				value: next.headless ? "1" : "0",
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}
		}).run();
	});
	return next;
}
//#endregion
//#region src/routes/api/settings/+server.ts
var GET = () => json(getAppSettings());
var PUT = async ({ request }) => {
	const payload = await request.json().catch(() => ({}));
	const settings = updateAppSettings({
		max_concurrent: payload.max_concurrent,
		headless: payload.headless
	});
	logInfo("app settings updated", settings);
	return json(settings);
};
//#endregion
export { GET, PUT };
