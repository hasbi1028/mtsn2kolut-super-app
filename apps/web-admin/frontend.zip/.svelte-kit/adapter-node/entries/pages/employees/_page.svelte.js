import { B as escape_html, R as attr, a as ensure_array_like, n as attr_class, o as head } from "../../../chunks/dev.js";
import "../../../chunks/index-server.js";
//#region src/lib/components/EmployeeForm.svelte
function EmployeeForm($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { onadd } = $$props;
		let form = {
			nip: "",
			nama: "",
			unit_kerja: "",
			pusaka_username: "",
			pusaka_password: ""
		};
		let loading = false;
		$$renderer.push(`<section class="card"><h2>Tambah Pegawai</h2> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="form-grid svelte-1mm5nd2"><input placeholder="NIP"${attr("value", form.nip)}/> <input placeholder="Nama"${attr("value", form.nama)}/> <input placeholder="Unit Kerja"${attr("value", form.unit_kerja)}/> <input placeholder="Username Pusaka"${attr("value", form.pusaka_username)}/> <input type="password" placeholder="Password Pusaka"${attr("value", form.pusaka_password)}/> <button class="btn"${attr("disabled", loading, true)}>${escape_html("Simpan")}</button></div></section>`);
	});
}
//#endregion
//#region src/lib/components/EmployeeList.svelte
function EmployeeList($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { employees, onrun, onstop, ondelete } = $$props;
		let confirmId = null;
		let busyId = null;
		function statusLabel(e) {
			const s = e.active_status || e.last_status;
			const t = e.active_run_type || e.last_run_type;
			if (!s) return null;
			return {
				status: s,
				tipe: {
					morning: "pagi",
					afternoon: "sore",
					checkin: "masuk",
					checkout: "pulang"
				}[t] || t
			};
		}
		function pillClass(status) {
			if (status === "running") return "pill-run";
			if (status === "queued") return "pill-queue";
			if (status === "success") return "pill-ok";
			if (status === "failed") return "pill-bad";
			return "pill-idle";
		}
		function pillIcon(status) {
			if (status === "running") return "⟳";
			if (status === "queued") return "…";
			if (status === "success") return "✓";
			if (status === "failed") return "✕";
			return "";
		}
		$$renderer.push(`<section class="card"><h2>Daftar Pegawai <span class="badge svelte-opk1xk">${escape_html(employees.length)}</span></h2> <div class="stack">`);
		if (employees.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="muted">Belum ada data pegawai.</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <!--[-->`);
		const each_array = ensure_array_like(employees);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let e = each_array[$$index];
			const sl = statusLabel(e);
			$$renderer.push(`<div${attr_class("row svelte-opk1xk", void 0, { "row-active": e.active_status === "running" })}><div class="info"><div class="name-row svelte-opk1xk"><span class="name svelte-opk1xk">${escape_html(e.nama)}</span> `);
			if (sl) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span${attr_class(`spill ${pillClass(sl.status)}`, "svelte-opk1xk")}>${escape_html(pillIcon(sl.status))} ${escape_html(sl.status)}${escape_html(sl.tipe ? " · " + sl.tipe : "")}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="meta muted svelte-opk1xk">${escape_html(e.nip)} • ${escape_html(e.unit_kerja)}</div></div> `);
			if (confirmId === e.id) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="side svelte-opk1xk"><span class="warn-text svelte-opk1xk">Hapus beserta semua job &amp; absensi?</span> <button class="btn small danger svelte-opk1xk"${attr("disabled", busyId === e.id, true)}>${escape_html(busyId === e.id ? "..." : "Ya, Hapus")}</button> <button class="btn small ghost">Batal</button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="side svelte-opk1xk"><button class="btn small"${attr("disabled", busyId === e.id, true)}>Pagi</button> <button class="btn small ghost"${attr("disabled", busyId === e.id, true)}>Sore</button> <button class="btn small green svelte-opk1xk"${attr("disabled", busyId === e.id, true)}>☀ Masuk</button> <button class="btn small orange svelte-opk1xk"${attr("disabled", busyId === e.id, true)}>🌙 Pulang</button> <button class="btn small stop svelte-opk1xk"${attr("disabled", busyId === e.id || !e.active_status, true)}>${escape_html(busyId === e.id ? "..." : "■ Stop")}</button> <button class="btn small ghost danger-outline svelte-opk1xk">Hapus</button></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--></div></section>`);
	});
}
//#endregion
//#region src/routes/employees/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let employees = [];
		let toast = "";
		async function load() {
			employees = (await (await fetch("/api/employees")).json()).items;
		}
		async function runNow(employee_id, run_type) {
			await fetch("/api/jobs/run-now", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({
					employee_id,
					run_type
				})
			});
			showToast(`Job ${{
				morning: "pagi",
				afternoon: "sore",
				checkin: "absensi masuk",
				checkout: "absensi pulang"
			}[run_type] || run_type} berhasil di-queue.`);
		}
		function handleStop(_id, cancelled) {
			showToast(cancelled > 0 ? `${cancelled} job dibatalkan.` : "Tidak ada job aktif untuk pegawai ini.");
		}
		function showToast(msg) {
			toast = msg;
			setTimeout(() => toast = "", 3e3);
		}
		head("1hfo2i2", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Pegawai — Pusaka Worker</title>`);
			});
		});
		$$renderer.push(`<h2 class="page-title svelte-1hfo2i2">Manajemen Pegawai</h2> `);
		if (toast) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="toast svelte-1hfo2i2">${escape_html(toast)}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		EmployeeForm($$renderer, { onadd: load });
		$$renderer.push(`<!----> `);
		EmployeeList($$renderer, {
			employees,
			onrun: runNow,
			onstop: handleStop,
			ondelete: load
		});
		$$renderer.push(`<!---->`);
	});
}
//#endregion
export { _page as default };
