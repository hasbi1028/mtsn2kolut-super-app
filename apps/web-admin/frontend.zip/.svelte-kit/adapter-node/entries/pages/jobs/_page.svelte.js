import { B as escape_html, R as attr, a as ensure_array_like, n as attr_class, o as head } from "../../../chunks/dev.js";
import "../../../chunks/index-server.js";
//#region src/routes/jobs/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let jobs = [];
		let filterStatus = "";
		let limit = 50;
		let autoRefresh = true;
		async function load() {
			const params = new URLSearchParams({ limit: String(limit) });
			jobs = (await (await fetch(`/api/jobs?${params}`)).json()).items;
		}
		function statusClass(s) {
			if (s === "success") return "ok";
			if (s === "failed") return "bad";
			if (s === "running") return "run";
			return "idle";
		}
		head("4b134t", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Jobs — Pusaka Worker</title>`);
			});
		});
		$$renderer.push(`<div class="toolbar svelte-4b134t"><h2 class="page-title svelte-4b134t">Riwayat Job</h2> <div class="controls svelte-4b134t">`);
		$$renderer.select({
			value: filterStatus,
			onchange: load,
			class: ""
		}, ($$renderer) => {
			$$renderer.option({ value: "" }, ($$renderer) => {
				$$renderer.push(`Semua Status`);
			});
			$$renderer.option({ value: "queued" }, ($$renderer) => {
				$$renderer.push(`Queued`);
			});
			$$renderer.option({ value: "running" }, ($$renderer) => {
				$$renderer.push(`Running`);
			});
			$$renderer.option({ value: "success" }, ($$renderer) => {
				$$renderer.push(`Success`);
			});
			$$renderer.option({ value: "failed" }, ($$renderer) => {
				$$renderer.push(`Failed`);
			});
		}, "svelte-4b134t");
		$$renderer.push(` `);
		$$renderer.select({
			value: limit,
			onchange: load,
			class: ""
		}, ($$renderer) => {
			$$renderer.option({ value: 20 }, ($$renderer) => {
				$$renderer.push(`20 baris`);
			});
			$$renderer.option({ value: 50 }, ($$renderer) => {
				$$renderer.push(`50 baris`);
			});
			$$renderer.option({ value: 100 }, ($$renderer) => {
				$$renderer.push(`100 baris`);
			});
			$$renderer.option({ value: 200 }, ($$renderer) => {
				$$renderer.push(`200 baris`);
			});
		}, "svelte-4b134t");
		$$renderer.push(` <label class="check"><input type="checkbox"${attr("checked", autoRefresh, true)}/> Auto-refresh</label> <button class="btn small">↺ Refresh</button></div></div> <section class="card"><div class="table-wrap"><table><thead><tr><th>Waktu</th><th>Nama</th><th>Tipe</th><th>Status</th><th>Attempt</th><th>Worker</th><th>Retry At</th><th>Error</th></tr></thead><tbody><!--[-->`);
		const each_array = ensure_array_like(jobs);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let j = each_array[$$index];
			$$renderer.push(`<tr><td class="nowrap svelte-4b134t">${escape_html(j.created_at_wita || j.created_at)}</td><td>${escape_html(j.nama)}</td><td>${escape_html(j.run_type)}</td><td><span${attr_class(`pill ${statusClass(j.status)}`, "svelte-4b134t")}>${escape_html(j.status)}</span></td><td>${escape_html(j.attempts)}/${escape_html(j.max_attempts)}</td><td class="muted nowrap svelte-4b134t">${escape_html(j.claimed_by || "-")}</td><td class="muted nowrap svelte-4b134t">${escape_html(j.next_retry_at || "-")}</td><td class="muted err svelte-4b134t">${escape_html(j.error_message || "-")}</td></tr>`);
		}
		$$renderer.push(`<!--]-->`);
		if (jobs.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<tr><td colspan="8" class="muted">Tidak ada job.</td></tr>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></tbody></table></div></section>`);
	});
}
//#endregion
export { _page as default };
