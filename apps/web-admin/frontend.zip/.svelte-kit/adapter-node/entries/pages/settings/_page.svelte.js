import { B as escape_html, R as attr, a as ensure_array_like, o as head, r as bind_props } from "../../../chunks/dev.js";
import "../../../chunks/index-server.js";
//#region src/lib/components/WorkerSettings.svelte
function WorkerSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { settings = void 0, onsave } = $$props;
		$$renderer.push(`<section class="card"><h2>Worker Settings</h2> <div class="settings-grid svelte-16wyum1"><label class="svelte-16wyum1"><span class="svelte-16wyum1">Max Concurrent</span> <input type="number" min="1" max="20"${attr("value", settings.max_concurrent)}/></label> <label class="check svelte-16wyum1"><span class="svelte-16wyum1">Headless Mode</span> <input type="checkbox"${attr("checked", settings.headless, true)}/></label> <div class="settings-actions svelte-16wyum1"><button class="btn">Simpan Setting</button> <p class="muted small-note svelte-16wyum1">Perubahan max concurrent/headless dipakai worker dalam ~30 detik tanpa restart.</p></div></div></section>`);
		bind_props($$props, { settings });
	});
}
//#endregion
//#region src/lib/components/ScheduleList.svelte
function ScheduleList($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { schedules = void 0, onsave } = $$props;
		$$renderer.push(`<section class="card"><h2>Jadwal Otomatis</h2> <div class="stack"><!--[-->`);
		const each_array = ensure_array_like(schedules);
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let s = each_array[i];
			$$renderer.push(`<div class="schedule-row svelte-slc63j"><strong>${escape_html(s.label)}</strong> <input class="time"${attr("value", schedules[i].run_time)}/> `);
			$$renderer.select({ value: schedules[i].run_type }, ($$renderer) => {
				$$renderer.option({ value: "morning" }, ($$renderer) => {
					$$renderer.push(`morning`);
				});
				$$renderer.option({ value: "afternoon" }, ($$renderer) => {
					$$renderer.push(`afternoon`);
				});
			});
			$$renderer.push(` <label class="check"><input type="checkbox"${attr("checked", schedules[i].is_enabled, true)}/> aktif</label></div>`);
		}
		$$renderer.push(`<!--]--></div> <button class="btn" style="margin-top:12px">Simpan Jadwal</button></section>`);
		bind_props($$props, { schedules });
	});
}
//#endregion
//#region src/routes/settings/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let appSettings = {
			max_concurrent: 1,
			headless: false
		};
		let schedules = [];
		let toast = "";
		async function load() {
			const [st, s] = await Promise.all([fetch("/api/settings").then((r) => r.json()), fetch("/api/schedules").then((r) => r.json())]);
			appSettings = st;
			schedules = s.items;
		}
		async function saveSettings() {
			await fetch("/api/settings", {
				method: "PUT",
				headers: { "content-type": "application/json" },
				body: JSON.stringify(appSettings)
			});
			showToast("Pengaturan worker disimpan. Akan aktif dalam ~30 detik.");
		}
		async function saveSchedules() {
			await fetch("/api/schedules", {
				method: "PUT",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ schedules })
			});
			showToast("Jadwal otomatis disimpan.");
			await load();
		}
		function showToast(msg) {
			toast = msg;
			setTimeout(() => toast = "", 3500);
		}
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			head("1i19ct2", $$renderer, ($$renderer) => {
				$$renderer.title(($$renderer) => {
					$$renderer.push(`<title>Pengaturan — Pusaka Worker</title>`);
				});
			});
			$$renderer.push(`<h2 class="page-title svelte-1i19ct2">Pengaturan</h2> `);
			if (toast) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="toast svelte-1i19ct2">${escape_html(toast)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			WorkerSettings($$renderer, {
				onsave: saveSettings,
				get settings() {
					return appSettings;
				},
				set settings($$value) {
					appSettings = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----> `);
			ScheduleList($$renderer, {
				onsave: saveSchedules,
				get schedules() {
					return schedules;
				},
				set schedules($$value) {
					schedules = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!---->`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
	});
}
//#endregion
export { _page as default };
