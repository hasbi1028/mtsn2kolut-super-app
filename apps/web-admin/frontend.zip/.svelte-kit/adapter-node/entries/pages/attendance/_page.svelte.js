import { B as escape_html, R as attr, a as ensure_array_like, c as stringify, n as attr_class, o as head, z as clsx } from "../../../chunks/dev.js";
import "../../../chunks/index-server.js";
//#region src/routes/attendance/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let records = [];
		let filterDate = "";
		function stripWita(val) {
			return val ? val.replace(/\s*WITA$/i, "") : "–";
		}
		head("12uchig", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Absensi — Pusaka Worker</title>`);
			});
		});
		$$renderer.push(`<div class="bar svelte-12uchig"><span class="title svelte-12uchig">Absensi `);
		if (records.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="count svelte-12uchig">${escape_html(records.length)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></span> <div class="controls svelte-12uchig"><input type="date"${attr("value", filterDate)} class="svelte-12uchig"/> <button class="btn-sm svelte-12uchig">↺</button></div></div> <div class="tbl-wrap svelte-12uchig"><table class="svelte-12uchig"><thead class="svelte-12uchig"><tr class="svelte-12uchig"><th class="c-no svelte-12uchig">#</th><th class="svelte-12uchig">Nama</th><th class="c-time svelte-12uchig">Masuk</th><th class="c-time svelte-12uchig">Pulang</th></tr></thead><tbody class="svelte-12uchig"><!--[-->`);
		const each_array = ensure_array_like(records);
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let a = each_array[i];
			$$renderer.push(`<tr${attr_class(clsx(!a.jam_masuk ? "row-empty" : ""), "svelte-12uchig")}><td class="c-no dim svelte-12uchig">${escape_html(i + 1)}</td><td class="c-nama svelte-12uchig">${escape_html(a.nama)}</td><td${attr_class(`c-time ${stringify(a.jam_masuk ? "ok" : "dim")}`, "svelte-12uchig")}>${escape_html(stripWita(a.jam_masuk))}</td><td${attr_class(`c-time ${stringify(a.jam_pulang ? "ok" : "dim")}`, "svelte-12uchig")}>${escape_html(stripWita(a.jam_pulang))}</td></tr>`);
		}
		$$renderer.push(`<!--]-->`);
		if (records.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<tr class="svelte-12uchig"><td colspan="4" class="empty svelte-12uchig">Tidak ada data.</td></tr>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></tbody></table></div>`);
	});
}
//#endregion
export { _page as default };
