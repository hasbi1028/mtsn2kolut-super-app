import { B as escape_html, R as attr, a as ensure_array_like, c as stringify, n as attr_class } from "../../chunks/dev.js";
import "../../chunks/index-server.js";
//#region src/lib/components/QueueMonitor.svelte
function QueueMonitor($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { stats } = $$props;
		$$renderer.push(`<section class="card"><h2>Queue Monitor</h2> <div class="queue-grid svelte-1dwx3j9"><div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Queued</span><strong class="svelte-1dwx3j9">${escape_html(stats.queued)}</strong></div> <div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Running</span><strong class="svelte-1dwx3j9">${escape_html(stats.running)}</strong></div> <div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Success</span><strong class="svelte-1dwx3j9">${escape_html(stats.success)}</strong></div> <div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Failed</span><strong class="svelte-1dwx3j9">${escape_html(stats.failed)}</strong></div> <div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Retry Due</span><strong class="svelte-1dwx3j9">${escape_html(stats.retry_due)}</strong></div> <div class="qbox svelte-1dwx3j9"><span class="svelte-1dwx3j9">Total</span><strong class="svelte-1dwx3j9">${escape_html(stats.total)}</strong></div></div></section>`);
	});
}
//#endregion
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let queueStats = {
			queued: 0,
			running: 0,
			success: 0,
			failed: 0,
			retry_due: 0,
			total: 0
		};
		let recentJobs = [];
		let busy = {};
		let toast = {
			msg: "",
			type: "ok"
		};
		let confirmKey = "";
		function statusClass(s) {
			if (s === "success") return "ok";
			if (s === "failed") return "bad";
			if (s === "running") return "run";
			return "idle";
		}
		$$renderer.push(`<header class="card hero svelte-1uha8ag"><div><h1>Pusaka Worker Manager</h1> <p>Dashboard monitoring scraping absensi pegawai</p></div> <div class="btn-group svelte-1uha8ag"><button class="btn ghost"${attr("disabled", busy.sched, true)}>${escape_html(busy.sched ? "..." : "⚡ Trigger Scheduler")}</button> <button class="btn"${attr("disabled", busy.run_morning, true)}>${escape_html(busy.run_morning ? "..." : "▶ Run All Pagi")}</button> <button class="btn ghost"${attr("disabled", busy.run_afternoon, true)}>${escape_html(busy.run_afternoon ? "..." : "▶ Run All Sore")}</button> <div class="divider svelte-1uha8ag"></div> `);
		if (confirmKey === "cancel_all") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="warn-inline svelte-1uha8ag">Batalkan semua antrian?</span> <button class="btn small danger svelte-1uha8ag">Ya</button> <button class="btn small ghost">Tidak</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button class="btn ghost danger-outline svelte-1uha8ag"${attr("disabled", busy.cancel_all, true)}>✕ Cancel All Queue</button>`);
		}
		$$renderer.push(`<!--]--> `);
		if (confirmKey === "restart") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="warn-inline svelte-1uha8ag">Restart worker sekarang?</span> <button class="btn small danger svelte-1uha8ag">Ya</button> <button class="btn small ghost">Tidak</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button class="btn ghost danger-outline svelte-1uha8ag"${attr("disabled", busy.restart, true)}>↺ Restart Worker</button>`);
		}
		$$renderer.push(`<!--]--></div></header> `);
		if (toast.msg) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div${attr_class(`toast ${stringify(toast.type)}`, "svelte-1uha8ag")}>${escape_html(toast.msg)}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		QueueMonitor($$renderer, { stats: queueStats });
		$$renderer.push(`<!----> <section class="card"><div class="section-head svelte-1uha8ag"><h2 class="svelte-1uha8ag">Job Terbaru</h2> <a href="/jobs" class="see-all svelte-1uha8ag">Lihat semua →</a></div> <div class="table-wrap"><table><thead><tr><th>Waktu</th><th>Nama</th><th>Tipe</th><th>Status</th><th>Worker</th></tr></thead><tbody><!--[-->`);
		const each_array = ensure_array_like(recentJobs);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let j = each_array[$$index];
			$$renderer.push(`<tr><td>${escape_html(j.created_at_wita || j.created_at)}</td><td>${escape_html(j.nama)}</td><td>${escape_html(j.run_type)}</td><td><span${attr_class(`pill ${statusClass(j.status)}`, "svelte-1uha8ag")}>${escape_html(j.status)}</span></td><td class="muted">${escape_html(j.claimed_by || "-")}</td></tr>`);
		}
		$$renderer.push(`<!--]-->`);
		if (recentJobs.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<tr><td colspan="5" class="muted">Belum ada job.</td></tr>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></tbody></table></div></section>`);
	});
}
//#endregion
export { _page as default };
