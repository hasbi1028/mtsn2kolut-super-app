import { t as initScheduler } from "../chunks/scheduler.js";
//#region src/hooks.server.ts
initScheduler();
var handle = async ({ event, resolve }) => {
	return resolve(event);
};
//#endregion
export { handle };
