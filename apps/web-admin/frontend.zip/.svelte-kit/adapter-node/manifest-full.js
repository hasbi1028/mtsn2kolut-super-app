export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.PGVJ-pub.js",app:"_app/immutable/entry/app.DHzRdngc.js",imports:["_app/immutable/entry/start.PGVJ-pub.js","_app/immutable/chunks/KAguBumh.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/entry/app.DHzRdngc.js","_app/immutable/chunks/D9X_oCBZ.js","_app/immutable/chunks/DxLN9Q9A.js","_app/immutable/chunks/v_jBEYI6.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/api/attendance",
				pattern: /^\/api\/attendance\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/attendance/_server.ts.js'))
			},
			{
				id: "/api/employees",
				pattern: /^\/api\/employees\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/employees/_server.ts.js'))
			},
			{
				id: "/api/jobs",
				pattern: /^\/api\/jobs\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/jobs/_server.ts.js'))
			},
			{
				id: "/api/jobs/cancel-all",
				pattern: /^\/api\/jobs\/cancel-all\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/jobs/cancel-all/_server.ts.js'))
			},
			{
				id: "/api/jobs/cancel",
				pattern: /^\/api\/jobs\/cancel\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/jobs/cancel/_server.ts.js'))
			},
			{
				id: "/api/jobs/run-all",
				pattern: /^\/api\/jobs\/run-all\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/jobs/run-all/_server.ts.js'))
			},
			{
				id: "/api/jobs/run-now",
				pattern: /^\/api\/jobs\/run-now\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/jobs/run-now/_server.ts.js'))
			},
			{
				id: "/api/queue/stats",
				pattern: /^\/api\/queue\/stats\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/queue/stats/_server.ts.js'))
			},
			{
				id: "/api/scheduler/tick",
				pattern: /^\/api\/scheduler\/tick\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scheduler/tick/_server.ts.js'))
			},
			{
				id: "/api/schedules",
				pattern: /^\/api\/schedules\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/schedules/_server.ts.js'))
			},
			{
				id: "/api/settings",
				pattern: /^\/api\/settings\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/settings/_server.ts.js'))
			},
			{
				id: "/api/worker/claim",
				pattern: /^\/api\/worker\/claim\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/worker/claim/_server.ts.js'))
			},
			{
				id: "/api/worker/complete",
				pattern: /^\/api\/worker\/complete\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/worker/complete/_server.ts.js'))
			},
			{
				id: "/api/worker/fail",
				pattern: /^\/api\/worker\/fail\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/worker/fail/_server.ts.js'))
			},
			{
				id: "/api/worker/restart",
				pattern: /^\/api\/worker\/restart\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/worker/restart/_server.ts.js'))
			},
			{
				id: "/attendance",
				pattern: /^\/attendance\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/employees",
				pattern: /^\/employees\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/jobs",
				pattern: /^\/jobs\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/settings",
				pattern: /^\/settings\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
